# -*- coding: utf-8 -*-

from . import sale_advance_payment_wizard
